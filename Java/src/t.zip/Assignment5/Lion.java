package Assignment5;
/*
SUBCLASS LION
 */
public class Lion extends Animal{
    @Override
    String makeSound() {
        return "Growl";
    }
}
