package Assignment5;
/*
SUB CLASS TIGER
 */
public class Tiger extends Animal{
    @Override
    String makeSound() {
        return "Roar";
    }
}
