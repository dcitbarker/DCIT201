package Assignment5;
/*
SUB CLASS ELEPHANT

 */
public class Elephant extends Animal {

    @Override
    String makeSound() {
        return "Trumpets";
    }
}
