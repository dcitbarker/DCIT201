package Assignment6;

// SHAPE INTERFACE

public interface IShape {

    double getArea();

    double getPerimeter();
}